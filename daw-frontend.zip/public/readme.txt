Put impulse response files in public/irs (optional)
