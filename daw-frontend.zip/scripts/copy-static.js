const fs = require('fs')
const path = require('path')
const src = path.resolve(__dirname, '..', 'src', 'lib', 'distortion-processor.js')
const dest = path.resolve(__dirname, '..', 'dist', 'src', 'lib', 'distortion-processor.js')
if (fs.existsSync(src)) {
  fs.mkdirSync(path.dirname(dest), { recursive: true })
  fs.copyFileSync(src, dest)
}
const irSrc = path.resolve(__dirname, '..', 'public', 'irs')
const irDest = path.resolve(__dirname, '..', 'dist', 'public', 'irs')
if (fs.existsSync(irSrc)) {
  fs.cpSync(irSrc, irDest, { recursive: true })
}
