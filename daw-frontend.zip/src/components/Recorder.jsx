import React, { useEffect, useRef, useState } from 'react'
import { createAudioContext, createDistortionNode, createGain, getUserMediaStream, startMediaRecorder } from '../lib/audioUtils'
export default function Recorder({ onRecordedBlob }){
  const [ctx,setCtx]=useState(null); const [stream,setStream]=useState(null); const recRef=useRef(null); const [rec,setRec]=useState(false)
  useEffect(()=>{ const c=createAudioContext(); setCtx(c); return ()=>{ try{c.close()}catch(e){} } },[])
  async function openInput(){ const s=await getUserMediaStream(); setStream(s); const src=ctx.createMediaStreamSource(s); const pre=createGain(ctx,0.8); const dist=createDistortionNode(ctx,30); src.connect(pre); pre.connect(dist); dist.connect(ctx.destination) }
  function start(){ if(!stream) return alert('Open input first'); recRef.current = startMediaRecorder(stream, blob=>onRecordedBlob(blob)); setRec(true) }
  function stop(){ if(recRef.current) recRef.current.stop(); setRec(false) }
  return (<div className="p-4 bg-gray-800 rounded"><div className="flex gap-2"><button onClick={openInput} className="px-3 py-1 bg-indigo-600 rounded">Open</button>{!rec?<button onClick={start} className="px-3 py-1 bg-red-600 rounded">Record</button>:<button onClick={stop} className="px-3 py-1 bg-gray-600 rounded">Stop</button>}</div></div>)
}
