import React from 'react'
export default function Mixer({tracks,onSetVolume}){ return (<div className="p-4 bg-gray-900 rounded">{tracks.map((t,i)=>(<div key={i} className="flex items-center gap-3"><div className="w-1/2">{t.name}</div><input type="range" min="0" max="2" step="0.01" value={t.volume} onChange={e=>onSetVolume(i,+e.target.value)} /></div>))}</div>) }
