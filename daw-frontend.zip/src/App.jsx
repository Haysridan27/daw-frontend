import React, { useState, useRef } from 'react'
import Recorder from './components/Recorder'
import Mixer from './components/Mixer'
import { supabase } from './lib/supabaseClient'

export default function App(){
  const [tracks,setTracks]=useState([])
  const audioCtxRef = useRef(null)
  async function handleRecordedBlob(blob){
    const ab = await blob.arrayBuffer()
    if(!audioCtxRef.current) audioCtxRef.current = new (window.AudioContext || window.webkitAudioContext)()
    const audioBuffer = await audioCtxRef.current.decodeAudioData(ab)
    const newTrack = { id: Date.now(), buffer: audioBuffer, volume:1, name:`Track ${tracks.length+1}` }
    setTracks(prev=>[...prev,newTrack])
    const fileName = `tracks/${newTrack.id}.webm`
    try{
      await supabase.storage.from('daw-tracks').upload(fileName, blob, { upsert: true })
    }catch(e){ console.error('upload', e) }
  }
  function onSetVolume(i,v){ setTracks(prev=>{ const c=[...prev]; c[i].volume=v; return c }) }
  function play(){
    if(!audioCtxRef.current) audioCtxRef.current = new (window.AudioContext || window.webkitAudioContext)()
    const ctx = audioCtxRef.current; const now = ctx.currentTime
    tracks.forEach(t=>{ const s = ctx.createBufferSource(); s.buffer = t.buffer; const g = ctx.createGain(); g.gain.value = t.volume; s.connect(g).connect(ctx.destination); s.start(now); t._src=s })
  }
  function stop(){ tracks.forEach(t=>{ if(t._src) try{ t._src.stop() }catch(e){} }) }
  return (<div className="min-h-screen p-6 text-white"><h1 className="text-2xl font-bold mb-4">DAW Prototype</h1><div className="grid grid-cols-3 gap-4"><div className="col-span-1"><Recorder onRecordedBlob={handleRecordedBlob} /><div className="mt-4"><button onClick={play} className="px-3 py-1 bg-green-600 rounded mr-2">Play</button><button onClick={stop} className="px-3 py-1 bg-yellow-600 rounded">Stop</button></div></div><div className="col-span-2"><Mixer tracks={tracks} onSetVolume={onSetVolume} /><div className="mt-4 bg-gray-800 p-4 rounded">Tracks list:{tracks.map(t=>(<div key={t.id} className="text-sm text-gray-300">{t.name} — {Math.round(t.buffer.duration)}s</div>))}</div></div></div></div>)
}
